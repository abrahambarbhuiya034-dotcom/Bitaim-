package com.bitaim.carromaim.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import com.bitaim.carromaim.cv.Coin;
import com.bitaim.carromaim.cv.GameState;
import com.bitaim.carromaim.cv.TrajectorySimulator;

import java.util.ArrayList;
import java.util.List;

/**
 * AimOverlayView — v2.1
 *
 * Changes from v2.0:
 *   - Striker is DRAGGABLE again: touch near it and drag to reposition.
 *   - Board corners are DRAGGABLE: four gold corner handles let you
 *     resize/move the board rectangle while in-game.
 *   - Only a SINGLE aim line is drawn (striker to target, direct).
 *   - Auto-detect state is accepted as starting position but the user
 *     can override striker and board corners by hand.
 */
public class AimOverlayView extends View {

    public static final String MODE_DIRECT = "DIRECT";
    public static final String MODE_AI     = "AI";
    public static final String MODE_GOLDEN = "GOLDEN";
    public static final String MODE_LUCKY  = "LUCKY";
    public static final String MODE_ALL    = "ALL";

    private final TrajectorySimulator simulator = new TrajectorySimulator();

    private String    shotMode       = MODE_DIRECT;
    private PointF    targetPos;
    private PointF    strikerPos;
    private float     strikerRadius  = 0;
    private GameState detected;
    private float     marginOffsetX  = 0f, marginOffsetY = 0f;
    private float     sensitivity    = 1.0f;
    private final float dp;

    private RectF   boardRect;
    private boolean boardManuallySet = false;

    private static final int DRAG_NONE     = 0;
    private static final int DRAG_STRIKER  = 1;
    private static final int DRAG_TARGET   = 2;
    private static final int DRAG_CORNER_TL = 3;
    private static final int DRAG_CORNER_TR = 4;
    private static final int DRAG_CORNER_BL = 5;
    private static final int DRAG_CORNER_BR = 6;

    private int dragMode = DRAG_NONE;

    private final Paint mainLinePaint;
    private final Paint ghostExtPaint;
    private final Paint strikerFillPaint, strikerOutlinePaint, strikerHintPaint;
    private final Paint coinFillBlack, coinFillWhite, coinFillRed, coinOutlinePaint;
    private final Paint pocketPaint;
    private final Paint targetPaint;
    private final Paint textPaint, boardPaint;
    private final Paint cornerFillPaint, cornerStrokePaint;

    public AimOverlayView(Context context) {
        super(context);
        dp = context.getResources().getDisplayMetrics().density;

        mainLinePaint = stroke(Color.parseColor("#FFD700"), 3.5f);

        ghostExtPaint = stroke(Color.parseColor("#99FFD700"), 2.0f);
        ghostExtPaint.setPathEffect(new DashPathEffect(new float[]{12*dp, 8*dp}, 0));

        strikerFillPaint    = fill(Color.parseColor("#55FFFFFF"));
        strikerOutlinePaint = stroke(Color.parseColor("#FFD700"), 2.5f);
        strikerHintPaint    = stroke(Color.parseColor("#66FFD700"), 1.5f);
        strikerHintPaint.setPathEffect(new DashPathEffect(new float[]{5*dp, 4*dp}, 0));

        coinFillBlack   = fill(Color.parseColor("#AA222222"));
        coinFillWhite   = fill(Color.parseColor("#AAFFFFFF"));
        coinFillRed     = fill(Color.parseColor("#AAFF3D71"));
        coinOutlinePaint = stroke(Color.parseColor("#88FFFFFF"), 1.5f);

        pocketPaint = fill(Color.parseColor("#882ECC71"));

        targetPaint = stroke(Color.WHITE, 2f);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(12 * dp);
        textPaint.setShadowLayer(2 * dp, 0, 0, Color.BLACK);

        boardPaint = stroke(Color.parseColor("#55FFD700"), 1.5f);
        boardPaint.setPathEffect(new DashPathEffect(new float[]{8*dp, 6*dp}, 0));

        cornerFillPaint   = fill(Color.parseColor("#CCFFD700"));
        cornerStrokePaint = stroke(Color.parseColor("#FFD700"), 2f);

        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    private Paint stroke(int color, float w) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color); p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w * dp);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        return p;
    }
    private Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color); p.setStyle(Paint.Style.FILL);
        return p;
    }

    // ── Public API ───────────────────────────────────────────────────────────

    public void setShotMode(String mode)              { this.shotMode = mode; postInvalidate(); }
    public void setMarginOffset(float dx, float dy)  { marginOffsetX = dx; marginOffsetY = dy; postInvalidate(); }
    public void setSensitivity(float v)              { sensitivity = Math.max(0.3f, Math.min(v, 3f)); postInvalidate(); }

    public void setDetectedState(GameState s) {
        this.detected = s;
        if (s != null && s.striker != null && dragMode != DRAG_STRIKER) {
            if (strikerPos == null) {
                strikerPos   = new PointF(s.striker.pos.x, s.striker.pos.y);
                strikerRadius = s.striker.radius;
            }
        }
        if (s != null && s.board != null && !boardManuallySet) {
            boardRect = new RectF(s.board);
        }
        postInvalidate();
    }

    // ── Touch ────────────────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float rx = event.getX() + marginOffsetX;
        float ry = event.getY() + marginOffsetY;
        float ex = event.getX();
        float ey = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                dragMode = pickDragTarget(ex, ey);
                if (dragMode == DRAG_NONE) {
                    targetPos = new PointF(rx, ry);
                    dragMode  = DRAG_TARGET;
                }
                postInvalidate();
                return true;

            case MotionEvent.ACTION_MOVE:
                switch (dragMode) {
                    case DRAG_STRIKER:
                        if (strikerPos == null) strikerPos = new PointF();
                        strikerPos.set(rx, ry);
                        break;
                    case DRAG_TARGET:
                        if (targetPos == null) targetPos = new PointF();
                        targetPos.set(rx, ry);
                        break;
                    case DRAG_CORNER_TL:
                        if (boardRect != null) { boardRect.left = ex; boardRect.top = ey; boardManuallySet = true; }
                        break;
                    case DRAG_CORNER_TR:
                        if (boardRect != null) { boardRect.right = ex; boardRect.top = ey; boardManuallySet = true; }
                        break;
                    case DRAG_CORNER_BL:
                        if (boardRect != null) { boardRect.left = ex; boardRect.bottom = ey; boardManuallySet = true; }
                        break;
                    case DRAG_CORNER_BR:
                        if (boardRect != null) { boardRect.right = ex; boardRect.bottom = ey; boardManuallySet = true; }
                        break;
                }
                postInvalidate();
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragMode = DRAG_NONE;
                postInvalidate();
                return true;
        }
        return super.onTouchEvent(event);
    }

    private int pickDragTarget(float x, float y) {
        float touchR = 38 * dp;

        if (strikerPos != null) {
            float r = Math.max(strikerRadius, 20 * dp) + touchR;
            if (dist(x, y, strikerPos.x, strikerPos.y) < r) return DRAG_STRIKER;
        }

        if (boardRect != null) {
            float ch = 24 * dp;
            if (dist(x, y, boardRect.left,  boardRect.top)    < ch) return DRAG_CORNER_TL;
            if (dist(x, y, boardRect.right, boardRect.top)    < ch) return DRAG_CORNER_TR;
            if (dist(x, y, boardRect.left,  boardRect.bottom) < ch) return DRAG_CORNER_BL;
            if (dist(x, y, boardRect.right, boardRect.bottom) < ch) return DRAG_CORNER_BR;
        }

        return DRAG_NONE;
    }

    private float dist(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2, dy = y1 - y2;
        return (float) Math.sqrt(dx*dx + dy*dy);
    }

    // ── Draw ─────────────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        GameState s = detected;
        if (s == null) s = synthFallback();

        if (strikerPos == null && s != null && s.striker != null) {
            strikerPos   = new PointF(s.striker.pos.x, s.striker.pos.y);
            strikerRadius = s.striker.radius;
        }
        if (boardRect == null && s != null && s.board != null) {
            boardRect = new RectF(s.board);
        }

        if (strikerPos == null) {
            drawHint(canvas, "Tap & drag to place striker  •  tap elsewhere to aim");
            return;
        }

        // Board + corner handles
        if (boardRect != null) {
            canvas.drawRect(boardRect, boardPaint);
            drawCorner(canvas, boardRect.left,  boardRect.top);
            drawCorner(canvas, boardRect.right, boardRect.top);
            drawCorner(canvas, boardRect.left,  boardRect.bottom);
            drawCorner(canvas, boardRect.right, boardRect.bottom);
        }

        // Pockets
        if (s != null) {
            for (PointF p : s.pockets) {
                canvas.drawCircle(p.x, p.y, 14 * dp, pocketPaint);
            }
            for (Coin c : s.coins) {
                Paint fillP = (c.color == Coin.COLOR_BLACK) ? coinFillBlack
                            : (c.color == Coin.COLOR_RED)   ? coinFillRed
                                                            : coinFillWhite;
                canvas.drawCircle(c.pos.x, c.pos.y, c.radius, fillP);
                canvas.drawCircle(c.pos.x, c.pos.y, c.radius, coinOutlinePaint);
            }
        }

        // Striker
        float sr = strikerRadius > 0 ? strikerRadius : 16 * dp;
        canvas.drawCircle(strikerPos.x, strikerPos.y, sr, strikerFillPaint);
        canvas.drawCircle(strikerPos.x, strikerPos.y, sr, strikerOutlinePaint);
        canvas.drawCircle(strikerPos.x, strikerPos.y, sr + 9 * dp, strikerHintPaint);

        if (targetPos == null) {
            drawHint(canvas, "Tap board to aim  •  drag gold striker or board corners");
            return;
        }

        // Target crosshair
        float cs = 13 * dp;
        canvas.drawCircle(targetPos.x, targetPos.y, 8 * dp, targetPaint);
        canvas.drawLine(targetPos.x - cs, targetPos.y, targetPos.x + cs, targetPos.y, targetPaint);
        canvas.drawLine(targetPos.x, targetPos.y - cs, targetPos.x, targetPos.y + cs, targetPaint);

        // Main aim line
        canvas.drawLine(strikerPos.x, strikerPos.y, targetPos.x, targetPos.y, mainLinePaint);

        // Ghost extension beyond target
        float ddx = targetPos.x - strikerPos.x;
        float ddy = targetPos.y - strikerPos.y;
        float len = dist(strikerPos.x, strikerPos.y, targetPos.x, targetPos.y);
        if (len > 1) {
            float nx = ddx / len, ny = ddy / len;
            canvas.drawLine(targetPos.x, targetPos.y,
                    targetPos.x + nx * 350 * dp,
                    targetPos.y + ny * 350 * dp,
                    ghostExtPaint);
        }

        // Angle label
        drawAngleLabel(canvas, strikerPos, targetPos);
    }

    private void drawCorner(Canvas canvas, float x, float y) {
        float r = 11 * dp;
        canvas.drawCircle(x, y, r, cornerFillPaint);
        canvas.drawCircle(x, y, r, cornerStrokePaint);
    }

    private void drawAngleLabel(Canvas canvas, PointF from, PointF to) {
        double angle = Math.toDegrees(Math.atan2(to.y - from.y, to.x - from.x));
        if (angle < 0) angle += 360;
        canvas.drawText(String.format("%.1f\u00b0", angle),
                (from.x + to.x) / 2f + 10 * dp,
                (from.y + to.y) / 2f - 8 * dp,
                textPaint);
    }

    private void drawHint(Canvas canvas, String msg) {
        canvas.drawText(msg, 24 * dp, 60 * dp, textPaint);
    }

    private GameState synthFallback() {
        if (getWidth() == 0 || getHeight() == 0) return null;
        GameState s = new GameState();
        int w = getWidth(), h = getHeight();
        float side = Math.min(w, h) * 0.90f;
        float cx = w / 2f, cy = h / 2f;
        s.board = new RectF(cx - side/2f, cy - side/2f, cx + side/2f, cy + side/2f);
        s.pockets.add(new PointF(s.board.left  + 20*dp, s.board.top    + 20*dp));
        s.pockets.add(new PointF(s.board.right - 20*dp, s.board.top    + 20*dp));
        s.pockets.add(new PointF(s.board.left  + 20*dp, s.board.bottom - 20*dp));
        s.pockets.add(new PointF(s.board.right - 20*dp, s.board.bottom - 20*dp));
        s.coins = new ArrayList<>();
        float r = 14 * dp;
        for (int i = -2; i <= 2; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) continue;
                int color = ((i + j) & 1) == 0 ? Coin.COLOR_BLACK : Coin.COLOR_WHITE;
                s.coins.add(new Coin(cx + i * 36*dp, cy + j * 36*dp, r, color, false));
            }
        }
        s.coins.add(new Coin(cx, cy, r, Coin.COLOR_RED, false));
        s.striker = new Coin(cx, s.board.bottom - 80*dp, 16*dp, Coin.COLOR_STRIKER, true);
        return s;
    }
}
