/**
 * BitAim — Carrom Pool Aim Assistant
 * v2.1 — Draggable striker, adjustable board corners, single aim line
 */

import React, {useState, useEffect, useCallback} from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Alert, Switch,
  ScrollView, Platform, StatusBar, NativeModules, Linking,
} from 'react-native';
import Slider from '@react-native-community/slider';

const {OverlayModule} = NativeModules;

export default function App() {
  const [hasOverlay,    setHasOverlay]    = useState(false);
  const [overlayActive, setOverlayActive] = useState(false);
  const [autoDetect,    setAutoDetect]    = useState(false);
  const [sensitivity,   setSensitivity]   = useState(1.0);
  const [detectThreshold, setDetectThreshold] = useState(22);
  const [marginX, setMarginX] = useState(0);
  const [marginY, setMarginY] = useState(0);

  useEffect(() => {
    refreshStatus();
    const t = setInterval(refreshStatus, 2000);
    return () => clearInterval(t);
  }, []);

  const refreshStatus = useCallback(async () => {
    try { const can = await OverlayModule.canDrawOverlays(); setHasOverlay(can); }
    catch { setHasOverlay(true); }
    try { const a = await OverlayModule.isAutoDetectActive(); setAutoDetect(a); }
    catch {}
  }, []);

  const requestOverlay = useCallback(() => {
    try {
      OverlayModule.requestOverlayPermission();
      setTimeout(refreshStatus, 1500);
    } catch {
      Alert.alert('Permission Needed',
        'Please grant "Display over other apps" in Settings.',
        [{text: 'Open Settings', onPress: () => Linking.openSettings()}]);
    }
  }, [refreshStatus]);

  const toggleOverlay = useCallback(async () => {
    if (!hasOverlay) { requestOverlay(); return; }
    try {
      if (overlayActive) {
        await OverlayModule.stopOverlay();
        setOverlayActive(false);
        setAutoDetect(false);
      } else {
        await OverlayModule.startOverlay();
        setOverlayActive(true);
      }
    } catch (e: any) { Alert.alert('Error', e.message || 'Could not toggle overlay'); }
  }, [hasOverlay, overlayActive, requestOverlay]);

  const toggleAutoDetect = useCallback(async () => {
    if (!overlayActive) {
      Alert.alert('Start Overlay First', 'Turn on the Aim Overlay before enabling auto-detect.');
      return;
    }
    try {
      if (autoDetect) {
        await OverlayModule.stopScreenCapture();
        setAutoDetect(false);
      } else {
        await OverlayModule.requestScreenCapture();
        setTimeout(refreshStatus, 2500);
      }
    } catch (e: any) { Alert.alert('Error', e.message || 'Could not toggle screen capture'); }
  }, [overlayActive, autoDetect, refreshStatus]);

  const handleSensitivity = useCallback((v: number) => {
    setSensitivity(v);
    try { OverlayModule.setSensitivity(v); } catch {}
  }, []);

  const handleThreshold = useCallback((v: number) => {
    setDetectThreshold(v);
    try { OverlayModule.setDetectionThreshold(v); } catch {}
  }, []);

  const handleMargin = useCallback((axis: 'x' | 'y', v: number) => {
    const nx = axis === 'x' ? v : marginX;
    const ny = axis === 'y' ? v : marginY;
    if (axis === 'x') setMarginX(v); else setMarginY(v);
    try { OverlayModule.setMarginOffset(nx, ny); } catch {}
  }, [marginX, marginY]);

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor="#0D0D1A" />

      <View style={s.header}>
        <Text style={s.logo}>Bit-Aim</Text>
        <Text style={s.subtitle}>Carrom Aim Assist  •  v2.1</Text>
      </View>

      <ScrollView style={s.scroll} contentContainerStyle={s.scrollContent}
        showsVerticalScrollIndicator={false}>

        {/* Permission banner */}
        {!hasOverlay && (
          <TouchableOpacity style={s.permBanner} onPress={requestOverlay}>
            <Text style={s.permBannerText}>Grant "Display over other apps" to use the overlay</Text>
            <Text style={s.permBannerCta}>Tap to grant →</Text>
          </TouchableOpacity>
        )}

        {/* Overlay + Auto-Detect */}
        <View style={s.card}>
          <Row label="Aim Overlay"
            sub={overlayActive
              ? 'Running — tap floating icon in-game to toggle lines'
              : 'Start to draw the aim line on top of Carrom Pool'}
            value={overlayActive}
            onToggle={toggleOverlay}
            trackOn="#FFD700" />

          <Divider />

          <Row label="Auto-Detect (CV)"
            sub={autoDetect
              ? 'Camera reading screen — striker & board detected automatically'
              : 'Use computer vision to auto-place striker/board (per-session)'}
            value={autoDetect}
            onToggle={toggleAutoDetect}
            trackOn="#00E5FF" />
        </View>

        {/* How it works in v2.1 */}
        <View style={s.card}>
          <Text style={s.cardTitle}>In-Game Controls</Text>
          <InfoRow icon="🟡" text="Drag the gold striker circle to reposition it anywhere on the board" />
          <InfoRow icon="🔶" text="Drag the 4 gold corner handles to resize/align the board outline" />
          <InfoRow icon="✛"  text="Tap anywhere else to set your aim target — the gold line updates instantly" />
          <InfoRow icon="📐" text="The angle label shows your shot direction in degrees" />
          <View style={s.tipBox}>
            <Text style={s.tipText}>
              💡 Auto-Detect sets the starting position automatically.
              You can still drag to fine-tune during the match.
            </Text>
          </View>
        </View>

        {/* Shot power */}
        <View style={s.card}>
          <View style={s.rowSpread}>
            <Text style={s.cardTitle}>Shot Power</Text>
            <Text style={s.valueLabel}>{sensitivity.toFixed(1)}x</Text>
          </View>
          <Slider style={s.slider}
            minimumValue={0.3} maximumValue={3.0} step={0.1}
            value={sensitivity} onValueChange={handleSensitivity}
            minimumTrackTintColor="#FFD700" maximumTrackTintColor="#333"
            thumbTintColor="#FFD700" />
          <View style={s.rowSpread}>
            <Text style={s.sliderEnd}>Soft</Text>
            <Text style={s.sliderEnd}>Hard</Text>
          </View>
        </View>

        {/* Detection sensitivity */}
        <View style={s.card}>
          <View style={s.rowSpread}>
            <Text style={s.cardTitle}>Detection Sensitivity</Text>
            <Text style={[s.valueLabel, {color: '#00E5FF'}]}>{detectThreshold}</Text>
          </View>
          <Text style={s.cardSub}>Lower = finds more circles. Higher = fewer, cleaner detections.</Text>
          <Slider style={s.slider}
            minimumValue={12} maximumValue={50} step={1}
            value={detectThreshold} onValueChange={handleThreshold}
            minimumTrackTintColor="#00E5FF" maximumTrackTintColor="#333"
            thumbTintColor="#00E5FF" />
          <View style={s.rowSpread}>
            <Text style={s.sliderEnd}>More (noisier)</Text>
            <Text style={s.sliderEnd}>Fewer (cleaner)</Text>
          </View>
        </View>

        {/* Touch offset calibration */}
        <View style={s.card}>
          <Text style={s.cardTitle}>Touch Offset Calibration</Text>
          <Text style={s.cardSub}>Nudge if the aim line doesn't line up with your touch point</Text>

          <Text style={s.offsetLabel}>X Offset: <Text style={s.offsetValue}>{marginX.toFixed(1)}</Text></Text>
          <Slider style={s.slider}
            minimumValue={-30} maximumValue={30} step={0.5}
            value={marginX} onValueChange={v => handleMargin('x', v)}
            minimumTrackTintColor="#00E5FF" maximumTrackTintColor="#333"
            thumbTintColor="#00E5FF" />

          <Text style={[s.offsetLabel, {marginTop: 6}]}>Y Offset: <Text style={s.offsetValue}>{marginY.toFixed(1)}</Text></Text>
          <Slider style={s.slider}
            minimumValue={-30} maximumValue={30} step={0.5}
            value={marginY} onValueChange={v => handleMargin('y', v)}
            minimumTrackTintColor="#00E5FF" maximumTrackTintColor="#333"
            thumbTintColor="#00E5FF" />

          <TouchableOpacity style={s.resetBtn} onPress={() => {
            setMarginX(0); setMarginY(0);
            try { OverlayModule.setMarginOffset(0, 0); } catch {}
          }}>
            <Text style={s.resetBtnText}>Reset Offsets</Text>
          </TouchableOpacity>
        </View>

        {/* Quick-start steps */}
        <View style={s.card}>
          <Text style={s.cardTitle}>Quick Start</Text>
          {[
            '1. Grant "Draw over apps" permission above',
            '2. Tap Aim Overlay to start',
            '3. (Optional) Enable Auto-Detect for automatic striker placement',
            '4. Open Carrom Pool',
            '5. Tap the floating icon to show/hide the overlay',
            '6. Drag the gold striker to your striker position',
            '7. Drag board corners to match the game board',
            '8. Tap the board to set where you want to aim',
          ].map(step => (
            <Text key={step} style={s.step}>{step}</Text>
          ))}
        </View>

        <View style={s.footer}>
          <Text style={s.footerText}>Bit-Aim v2.1  •  Single Line Mode  •  Android 6+</Text>
        </View>
      </ScrollView>
    </View>
  );
}

// ── Small components ─────────────────────────────────────────────────────────

function Row({label, sub, value, onToggle, trackOn}: {
  label: string; sub: string; value: boolean;
  onToggle: () => void; trackOn: string;
}) {
  return (
    <View style={s.row}>
      <View style={{flex: 1, paddingRight: 10}}>
        <Text style={s.cardTitle}>{label}</Text>
        <Text style={s.cardSub}>{sub}</Text>
      </View>
      <Switch value={value} onValueChange={onToggle}
        trackColor={{false: '#333', true: trackOn}}
        thumbColor={value ? '#FFF' : '#888'} />
    </View>
  );
}

function Divider() {
  return <View style={{height: 1, backgroundColor: '#22224488', marginVertical: 14}} />;
}

function InfoRow({icon, text}: {icon: string; text: string}) {
  return (
    <View style={s.infoRow}>
      <Text style={s.infoIcon}>{icon}</Text>
      <Text style={s.infoText}>{text}</Text>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  root:          {flex: 1, backgroundColor: '#0D0D1A'},
  header:        {
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight ?? 24 : 44,
    paddingBottom: 16, paddingHorizontal: 20,
    backgroundColor: '#13132A', borderBottomWidth: 1, borderBottomColor: '#222244',
  },
  logo:          {color: '#FFD700', fontSize: 26, fontWeight: '900', letterSpacing: 1},
  subtitle:      {color: '#8888BB', fontSize: 12, marginTop: 2},
  scroll:        {flex: 1},
  scrollContent: {padding: 16, paddingBottom: 40},
  permBanner:    {
    backgroundColor: '#2A1A00', borderWidth: 1, borderColor: '#FFD700',
    borderRadius: 10, padding: 14, marginBottom: 12,
  },
  permBannerText:{color: '#FFC', fontSize: 13},
  permBannerCta: {color: '#FFD700', fontSize: 13, fontWeight: '700', marginTop: 4},
  card:          {
    backgroundColor: '#16162E', borderRadius: 14, padding: 16,
    marginBottom: 14, borderWidth: 1, borderColor: '#222244',
  },
  cardTitle:     {color: '#FFFFFF', fontSize: 15, fontWeight: '700', marginBottom: 3},
  cardSub:       {color: '#8888BB', fontSize: 12, marginBottom: 6},
  row:           {flexDirection: 'row', alignItems: 'center'},
  rowSpread:     {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'},
  infoRow:       {flexDirection: 'row', alignItems: 'flex-start', marginBottom: 10},
  infoIcon:      {fontSize: 18, marginRight: 10, marginTop: 1},
  infoText:      {flex: 1, color: '#CCCCEE', fontSize: 13, lineHeight: 19},
  tipBox:        {
    backgroundColor: '#1A1A00', borderRadius: 8, padding: 10,
    borderWidth: 1, borderColor: '#FFD70044', marginTop: 4,
  },
  tipText:       {color: '#FFD700', fontSize: 12, lineHeight: 18},
  slider:        {width: '100%', height: 36},
  sliderEnd:     {color: '#666688', fontSize: 11},
  valueLabel:    {color: '#FFD700', fontSize: 16, fontWeight: '700'},
  offsetLabel:   {color: '#AAA', fontSize: 13, marginBottom: 2},
  offsetValue:   {color: '#00E5FF', fontWeight: '700'},
  resetBtn:      {
    marginTop: 8, paddingVertical: 8, borderRadius: 8,
    backgroundColor: '#1E1E3A', alignItems: 'center',
    borderWidth: 1, borderColor: '#444466',
  },
  resetBtnText:  {color: '#FF7777', fontSize: 13, fontWeight: '600'},
  step:          {color: '#CCCCEE', fontSize: 13, marginBottom: 6, paddingLeft: 2, lineHeight: 19},
  footer:        {alignItems: 'center', marginTop: 10},
  footerText:    {color: '#444466', fontSize: 11},
});
